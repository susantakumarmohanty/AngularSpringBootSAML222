import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { ErrorComponent } from './error/error.component';
import { GotodateComponent } from './home/gotodate/gotodate.component';
import { ValidationComponent } from './home/validation/validation.component';
import { ReviewComponent } from './home/review/review.component';
import { LoginComponent } from './login/login.component';
import {UserroutingService} from './userrouting.service';


const routes: Routes = [
  {path: '', canActivate: [UserroutingService], redirectTo: 'home', pathMatch:'full'},
  {
    path: 'home', component: HomeComponent,
  children: [
      {path:'gotodate', component:GotodateComponent},
      { path: 'validation', component: ValidationComponent },
      { path: 'review', component: ReviewComponent }
    ]
  },
  // { path: 'home', component: HomeComponent },
  // { path: 'gotodate', component: GotodateComponent },
  // { path: 'validation', component: ValidationComponent },
  // { path: 'review', component: ReviewComponent },
  { path: 'login', component: LoginComponent },
  {path:'**', component: ErrorComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes, { useHash: true })],
  exports: [RouterModule]
})
export class AppRoutingModule { }

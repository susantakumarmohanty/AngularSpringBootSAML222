import { Component } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import {ApiToken} from "./ApiToken";
import { Router } from '@angular/router';
import { ServiceService } from './service.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  apiToken: string;
  apiResult;
  //logoutSuccess: boolean

  constructor(private httpClient: HttpClient, private service: ServiceService) {
    //this.logoutSuccess = this.service.datas.logoutsuccess;
  }

  ngOnInit(): void {
    //this.logoutSuccess = this.service.datas.logoutsuccess;
    this.httpClient.get('/service/auth/token')
      .subscribe(
        r => this.handleTokenSuccess(r as ApiToken),
        error => this.handleTokenError(error));

  }

  handleTokenSuccess(apiToken: ApiToken) {
    this.apiToken = apiToken.token;
    localStorage.setItem("apiToken", apiToken.token);
    this.callApi();
  }

  handleTokenError(error: HttpErrorResponse) {

    if (error.status === 401) {
      setTimeout(() => window.location.replace('https://localhost:8443/saml/login'));
    }
  }

  callApi() {
    const apiToken = localStorage.getItem("apiToken");

    this.httpClient.get('/service/auth/user', {
      headers: {
        "x-auth-token": apiToken
      }
    }).subscribe(r => this.apiResult = JSON.stringify(r));
  }
}

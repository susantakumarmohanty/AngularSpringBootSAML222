import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { ServiceService } from '../service.service';
import { CookieService } from 'ngx-cookie-service';
//import {CookieService} from 'angular2-cookie/core';


@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  logoutFlag: boolean = false;
  logoutsuccess: boolean;

  constructor(private httpClient: HttpClient, private router:Router, private service: ServiceService, private cookieService: CookieService) { }

  ngOnInit() {
  }

  logout() {
    console.log('logout');
    localStorage.removeItem('apiToken');
    this.logoutsuccess = !this.logoutsuccess;
    this.service.datas.logoutsuccess = this.logoutsuccess;
    this.httpClient.get('service/saml/logout?local=true').subscribe();
    //this.cookieService.delete('JSESSIONID', '/', 'localhost');
    setTimeout(() => window.location.replace('./#/login'));
    return false;
  }
}

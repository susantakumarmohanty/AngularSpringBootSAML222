import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-gotodate',
  templateUrl: './gotodate.component.html',
  styleUrls: ['./gotodate.component.css']
})
export class GotodateComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

import { Component, OnInit } from '@angular/core';
import { ServiceService } from '../service.service';
import { HttpClient } from '@angular/common/http';


@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})

export class HomeComponent implements OnInit  {

  market = {
    "countries":[],
    "country":""
  }
  
  constructor(private http: HttpClient, private service: ServiceService) { }

  ngOnInit() {
    this.market.countries = ['Australia', 'China', 'Brazil', 'Japan', 'France', 'Italy'];
  }

  onMarketSelect(country:any) { 
    this.market.country = country;
    console.log("selected country:"+this.market.country);
 }
}

import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'searchfilter'
})
export class SearchFilter implements PipeTransform {
    transform(country:any):any {
        return country;
      }
}

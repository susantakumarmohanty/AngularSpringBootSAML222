import { TestBed } from '@angular/core/testing';

import { UserroutingService } from './userrouting.service';

describe('UserroutingService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: UserroutingService = TestBed.get(UserroutingService);
    expect(service).toBeTruthy();
  });
});

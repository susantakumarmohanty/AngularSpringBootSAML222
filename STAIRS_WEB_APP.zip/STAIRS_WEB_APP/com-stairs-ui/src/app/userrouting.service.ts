import { Injectable } from '@angular/core';
import { Router, CanActivate } from '@angular/router';
import { ServiceService } from './service.service';

@Injectable({
  providedIn: 'root'
})
export class UserroutingService implements CanActivate  {
  constructor(private router: Router, private service: ServiceService) { }

  canActivate() : boolean {
    if(this.service.datas.logoutsuccess) {
      this.router.navigate(['/login']);
    } else {
      return true;
    }
  }
}

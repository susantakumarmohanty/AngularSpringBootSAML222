package com.stairs.config;

public class SecurityConstant {

    public static final String JWT_SECRET = "yeWAgVDfb$!MFn@MCJVN7uqkznHbDLR#";

    private SecurityConstant(){}


}
